CREATE DATABASE  IF NOT EXISTS `ordinacija` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ordinacija`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ordinacija
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pacijent`
--

DROP TABLE IF EXISTS `pacijent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacijent` (
  `idpacijent` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `adresa` varchar(45) DEFAULT NULL,
  `broj_telefona` varchar(45) DEFAULT NULL,
  `jmbg` varchar(13) NOT NULL,
  PRIMARY KEY (`idpacijent`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacijent`
--

LOCK TABLES `pacijent` WRITE;
/*!40000 ALTER TABLE `pacijent` DISABLE KEYS */;
INSERT INTO `pacijent` VALUES (6,'Dejan','Nikolic','Novosadska 4','0698819982','3105000780013'),(7,'Jovan','Zivic','Temerinska 42','0699812122','1912965780010'),(8,'Kalamarko','Jovic','Svetosavska 10','0612223334','1231987900043'),(9,'Kalamarko','Zivic','Svetosavska 12','0698819982','12314');
/*!40000 ALTER TABLE `pacijent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregled`
--

DROP TABLE IF EXISTS `pregled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pregled` (
  `idpregled` int NOT NULL AUTO_INCREMENT,
  `tip` varchar(45) NOT NULL,
  `pocetakPregleda` timestamp NOT NULL,
  `krajPregleda` timestamp NOT NULL,
  `pacijent_id` int DEFAULT NULL,
  `zubar_id` int DEFAULT NULL,
  PRIMARY KEY (`idpregled`),
  KEY `FK_Pregled_Pacijent` (`pacijent_id`),
  KEY `FK_Pregled_Zubar` (`zubar_id`),
  CONSTRAINT `FK_Pregled_Pacijent` FOREIGN KEY (`pacijent_id`) REFERENCES `pacijent` (`idpacijent`),
  CONSTRAINT `FK_Pregled_Zubar` FOREIGN KEY (`zubar_id`) REFERENCES `zubar` (`idzubar`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregled`
--

LOCK TABLES `pregled` WRITE;
/*!40000 ALTER TABLE `pregled` DISABLE KEYS */;
INSERT INTO `pregled` VALUES (6,'ciscenjeKamenca','2024-05-28 12:30:00','2024-05-28 13:00:00',7,1),(7,'hitanPregled','2024-05-30 14:00:00','2024-05-30 15:00:00',8,1),(8,'plombiranje','2024-05-31 07:30:00','2024-05-31 08:00:00',9,1);
/*!40000 ALTER TABLE `pregled` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zubar`
--

DROP TABLE IF EXISTS `zubar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zubar` (
  `idzubar` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `jmbg` varchar(13) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `broj_telefona` varchar(45) NOT NULL,
  PRIMARY KEY (`idzubar`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zubar`
--

LOCK TABLES `zubar` WRITE;
/*!40000 ALTER TABLE `zubar` DISABLE KEYS */;
INSERT INTO `zubar` VALUES (1,'Marko','Baba','1812000840015','Svetosavska 26','0639938731');
/*!40000 ALTER TABLE `zubar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-27 23:21:00
