package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.repository.ZubarRepository;

@Controller
public class ZubarController {

	@Autowired
	private ZubarRepository zr;
	
	@PostMapping("/autorizacijaZubara")
	public String autorizacijaZubara(@RequestParam String jmbg, Model model) {
		if (zr.findByJmbg(jmbg) != null) {
			return "redirect:/lista";
		} else {
			model.addAttribute("greska", "Doslo je do greske prilikom autorizacije! Pokusajte ponovo.");
			return "autorizacijaZubara";
		}
	}
	
}
