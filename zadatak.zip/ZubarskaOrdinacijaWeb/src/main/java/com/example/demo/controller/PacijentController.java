package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.repository.PacijentRepository;

@Controller
public class PacijentController {

	@Autowired
	private PacijentRepository pr;
	
	@PostMapping("zakazivanjePregledaPacijent")
	public String autorizacijaPacijenta(@RequestParam String jmbg) {
		if (pr.findByJmbg(jmbg) != null) {
			return "zakazivanjePregledaPacijent";
		}
		return "index";
	}
	
}
