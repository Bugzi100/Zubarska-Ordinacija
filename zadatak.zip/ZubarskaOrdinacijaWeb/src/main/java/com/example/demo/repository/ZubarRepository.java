package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Zubar;

public interface ZubarRepository extends JpaRepository<Zubar, Integer>{

	Zubar findById(int zubarId);
	
	Zubar findByJmbg(String jmbg);
	
}
