package com.example.demo.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.PacijentRepository;
import com.example.demo.repository.PregledRepository;
import com.example.demo.repository.ZubarRepository;

import model.Pacijent;
import model.Pregled;

@Service
public class PregledService {

	@Autowired
	private PacijentRepository pr;
	
	@Autowired
	private ZubarRepository zr;
	
	@Autowired
	private PregledRepository pregRep;
	
	public List<Pregled> getPregledi() {
		return pregRep.findAll();
	}
	
	public String zakaziPregled(
			LocalDate datumPregleda,
			LocalTime vremePregleda,
			String tipPregleda, 
			String jmbg, 
			String adresa,
			String telefon,
			String ime,
			String prezime,
			int trajanjePregleda) {
		
		LocalDateTime pocetakPregleda = LocalDateTime.of(datumPregleda, vremePregleda);
		LocalDateTime krajPregleda = pocetakPregleda.plusMinutes(trajanjePregleda);
		
		if (pocetakPregleda.isAfter(LocalDateTime.now().plusMinutes(60)) && slobodanTermin(pocetakPregleda, krajPregleda)) {
			if (pocetakPregleda.getHour() >= 9 && pocetakPregleda.getHour() <= 16) {
				if (pocetakPregleda.getMinute() == 30 || pocetakPregleda.getMinute() == 0) {
					Pacijent pacijent = pr.findByJmbg(jmbg);
					if (pacijent == null) {
						pacijent = new Pacijent();
						pacijent.setIme(ime);
						pacijent.setPrezime(prezime);
						pacijent.setAdresa(adresa);
						pacijent.setBrojTelefona(telefon);
						pacijent.setJmbg(jmbg);
						pr.save(pacijent);
					}
					
					Pregled pregled = new Pregled();
					pregled.setPacijent(pacijent);
					pregled.setPocetakPregleda(pocetakPregleda);
					pregled.setKrajPregleda(pocetakPregleda.plusMinutes(trajanjePregleda));
					pregled.setTip(tipPregleda);
					pregled.setZubar(zr.findById(1));
					pregRep.save(pregled);
					
					return "uspesno";
				}		
			}
		} else {
			return "pogresnoVreme";
		}
		
		return "pogresniPodaci";
		
	}
	
	private boolean slobodanTermin(LocalDateTime pocetakPregleda, LocalDateTime krajPregleda) {
		List<Pregled> popunjeniTermini = pregRep.findAll();
		
		for (Pregled p : popunjeniTermini) {
			if (p.getPocetakPregleda().equals(pocetakPregleda) || p.getKrajPregleda().isAfter(pocetakPregleda)) {				
				return false;				
			}
		}
		
		return true;
		
	}
	
	public boolean otkaziPregled(String jmbg) {
		List<Pregled> popunjeniTermini = pregRep.findAll();
		
		for (Pregled p : popunjeniTermini) {
			if (p.getPacijent().getJmbg().equals(jmbg) && p.getPocetakPregleda().isAfter(LocalDateTime.now().plusMinutes(30))) {
				pregRep.delete(p);
				popunjeniTermini.remove(p);
				return true;
			}	
		}
		
		return false;
		
	}
	
}
