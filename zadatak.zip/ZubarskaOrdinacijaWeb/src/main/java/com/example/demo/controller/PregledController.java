package com.example.demo.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.services.PregledService;

import model.Pregled;

@Controller
public class PregledController {

	@Autowired
	private PregledService ps;
	
	@GetMapping("/lista")
	public String listaPregleda(Model model) {
	    List<Pregled> pregledi = ps.getPregledi();
	    
	    model.addAttribute("pregledi", pregledi);

	    return "listaPregleda";
	}

	
	@PostMapping("/zakazivanjePregleda")
	public String zakaziPregled(
			@RequestParam LocalDate datumPregleda,
			@RequestParam LocalTime vremePregleda,
			@RequestParam String tipPregleda, 
			@RequestParam String jmbg, 
			@RequestParam String adresa,
			@RequestParam String telefon,
			@RequestParam String ime,
			@RequestParam String prezime,
			@RequestParam int trajanjePregleda,
			Model model) {
		
		String zakazan = ps.zakaziPregled(datumPregleda, vremePregleda, tipPregleda, jmbg, adresa, telefon, ime, prezime, trajanjePregleda);
		
		if (zakazan.equals("uspesno")) {
			model.addAttribute("uspesno", "Uspesno ste zakazali pregled!");
		} else if (zakazan.equals("pogresnoVreme")){
			model.addAttribute("greska", "Greska prilikom zakazivanja! Termin koji ste odabrali je zauzet. Pokusajte sa drugim terminom.");
		} else {
			model.addAttribute("greska", "Greska prilikom zakazivanja! Podaci koje ste uneli su pogresni. Pokusajte ponovo.");
		}
		
		return "zakazivanjePregleda";
	}
	
	@PostMapping("/otkazivanjePregleda")
	public String otkaziPregled(@RequestParam String jmbg, Model model) {
		boolean pronadjenPacijent = ps.otkaziPregled(jmbg);
		
		if (pronadjenPacijent) {
			model.addAttribute("uspesno", "Uspesno ste otkazali pregled!");
		} else {
			model.addAttribute("greska", "Uneseni pacijent nema zakazanih pregleda, ili ste uneli pogresan JMBG.");
		}
		
		return "otkazivanjePregleda";
	}
	
}
