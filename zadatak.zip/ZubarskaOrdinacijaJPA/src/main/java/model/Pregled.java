package model;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.*;


/**
 * The persistent class for the pregled database table.
 * 
 */
@Entity
@NamedQuery(name="Pregled.findAll", query="SELECT p FROM Pregled p")
public class Pregled implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idpregled;

	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime pocetakPregleda;
	
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime krajPregleda;

	private String tip;

	@ManyToOne
    @JoinColumn(name = "pacijent_id")
    private Pacijent pacijent;

    @ManyToOne
    @JoinColumn(name = "zubar_id")
    private Zubar zubar;

	public Pregled() {
	}

	public int getIdpregled() {
		return this.idpregled;
	}

	public void setIdpregled(int idpregled) {
		this.idpregled = idpregled;
	}

	public LocalDateTime getPocetakPregleda() {
		return this.pocetakPregleda;
	}

	public void setPocetakPregleda(LocalDateTime pocetakPregleda) {
		this.pocetakPregleda = pocetakPregleda;
	}

	public String getTip() {
		return this.tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

	public Pacijent getPacijent() {
		return this.pacijent;
	}

	public void setPacijent(Pacijent pacijent) {
		this.pacijent = pacijent;
	}

	public Zubar getZubar() {
		return this.zubar;
	}

	public void setZubar(Zubar zubar) {
		this.zubar = zubar;
	}

	public LocalDateTime getKrajPregleda() {
		return krajPregleda;
	}

	public void setKrajPregleda(LocalDateTime krajPregleda) {
		this.krajPregleda = krajPregleda;
	}

}